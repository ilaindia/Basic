﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DbGuru
{
    public partial class DbSource : Form
    {
        protected SqlConnection GuruCon = null;
        public DbSource()
        {
            InitializeComponent();
            btnTestCon.Enabled = btnOk.Enabled = false;
            rdSqlAuth.Enabled = rdWinAuth.Enabled = false;
            lblUsername.Enabled = lblPassword.Enabled = lblDatabase.Enabled = false;
            txtUsername.Enabled = txtPassword.Enabled = cbDatabase.Enabled = false;

            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
            GuruCon = new SqlConnection();
            GuruCon.StateChange += new StateChangeEventHandler(this.State_Change);

            txtServer_Name.Text = Sql_Server.Data_Source;
            txtUsername.Text = Sql_Server.User_ID;
            txtPassword.Text = Sql_Server.Password;

            rdWinAuth.Checked = (Sql_Server.isFirst) ? Sql_Server.isFirst : Sql_Server.isWinAuth;
            rdSqlAuth.Checked = (Sql_Server.isFirst) ? false : (!Sql_Server.isWinAuth);
            rdWinAuth.CheckedChanged += new EventHandler(rdWinAuth_CheckedChanged);
            Sql_Server.isFirst = false;
            DataTable dt = new DataTable();
            dt.Columns.Add("name");
            DataRow dr = dt.NewRow();
            dr["name"] = (Sql_Server.isFirst) ? "master" : Sql_Server.Initial_Catalog;
            dt.Rows.Add(dr);
            cbDatabase.DisplayMember = cbDatabase.ValueMember = "name";
            cbDatabase.DataSource = dt;
            try
            {
                Load_Connection();
                Load_Db_List();
                rdWinAuth_CheckedChanged(this, null);
            }
            catch { }

            Sql_Server.isFirst = false;
        }

        private void DbSource_Load(object sender, System.EventArgs e)
        {

        }

        private void State_Change(object sender, StateChangeEventArgs e)
        {
            if (e.CurrentState == ConnectionState.Open)
            {
                Load_Db_List();
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                string Name = ((Button)sender).Name;
                Load_Connection();
                if (GuruCon.State == ConnectionState.Open)
                {
                    Load_Table_List();
                    GuruCon.Close();
                    GuruCon.Dispose();
                    if (Name == "btnTestCon")
                    {
                        MessageBox.Show("Connction Succeed..");
                    }
                    else if (Name == "btnOk")
                    {
                        this.Close();
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtServer_Name_TextChanged(object sender, EventArgs e)
        {
            if (txtServer_Name.Text.Length > 0)
            {
                rdSqlAuth.Enabled = rdWinAuth.Enabled = true;
            }
        }


        private void rdWinAuth_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.Enabled = txtUsername.Enabled = lblUsername.Enabled = lblPassword.Enabled = (rdSqlAuth.Checked);
        }

        protected void Load_Connection()
        {
            try
            {

                Sql_Server.Data_Source = txtServer_Name.Text;
                Sql_Server.User_ID = txtUsername.Text;
                Sql_Server.Password = txtPassword.Text;
                Sql_Server.isWinAuth = rdWinAuth.Checked;
                try
                {
                    Sql_Server.Initial_Catalog = cbDatabase.SelectedValue.ToString();
                }
                catch { Sql_Server.Initial_Catalog = "master"; }


                if (GuruCon.State == ConnectionState.Open)
                {
                    GuruCon.Close();
                    GuruCon.Dispose();
                }
                GuruCon.ConnectionString = Sql_Server.ConnectionString;
                GuruCon.Open();
            }
            catch
            {
                if (GuruCon.State == ConnectionState.Open)
                {
                    GuruCon.Close();
                    GuruCon.Dispose();
                }
                throw;
            }
        }

        protected void Load_Db_List()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT name, database_id FROM sys.databases";
            cmd.Connection = GuruCon;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.TableName = "Table1";
            da.Fill(dt);
            cbDatabase.DisplayMember = cbDatabase.ValueMember = "name";
            cbDatabase.DataSource = dt;
            if (dt.Rows.Count > 0)
            {
                cbDatabase.SelectedValue = Sql_Server.Initial_Catalog;
            }
            cbDatabase.Enabled = lblDatabase.Enabled = btnOk.Enabled = btnTestCon.Enabled = (dt.Rows.Count > 0);
        }
        protected void Load_Table_List()
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES";
                cmd.Connection = GuruCon;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                Sql_Server.Table_Colection = new DataTable();
                Sql_Server.Table_Colection.TableName = "Table1";
                da.Fill(Sql_Server.Table_Colection);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (GuruCon.State == ConnectionState.Open)
            {
                GuruCon.Close();
                GuruCon.Dispose();
                this.Close();
            }
            this.Close();
        }

    }
    public class Sql_Server
    {
        public static string Data_Source { get; set; }
        public static string Initial_Catalog { get; set; }
        public static string User_ID { get; set; }
        public static string Password { get; set; }
        public static bool isWinAuth { get; set; }
        public static string ConnectionString
        {
            get
            {
                string Con_Str_Template = (isWinAuth) ? "Data Source={0};Initial Catalog={1}Integrated Security=True" : "Data Source={0};Initial Catalog={1};Persist Security Info=True;User ID={2};Password={3}";
                return (isWinAuth) ? string.Format(Con_Str_Template, Data_Source, Initial_Catalog) : string.Format(Con_Str_Template, Data_Source, Initial_Catalog, User_ID, Password);
            }
        }
        public static bool isFirst { get; set; }
        public static DataTable Table_Colection { get; set; }
    }
}
