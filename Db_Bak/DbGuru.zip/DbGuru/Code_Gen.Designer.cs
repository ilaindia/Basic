﻿namespace DbGuru
{
    partial class Code_Gen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Code_Gen));
            this.btnAdd_Connection = new System.Windows.Forms.Button();
            this.txtConnectionString = new System.Windows.Forms.TextBox();
            this.txtData_Layer_Name = new System.Windows.Forms.TextBox();
            this.txtBusiness_Layer_Name = new System.Windows.Forms.TextBox();
            this.txtAbstract_Class_Name = new System.Windows.Forms.TextBox();
            this.lblData_Layer_Name = new System.Windows.Forms.Label();
            this.lblBusiness_Layer_Name = new System.Windows.Forms.Label();
            this.lblAbstract_Class_Name = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.RichTextBox();
            this.Code_Gen_Process = new System.ComponentModel.BackgroundWorker();
            this.ckTableName = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.Code_Gen_Status = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblCode_Gen_Status = new System.Windows.Forms.ToolStripStatusLabel();
            this.progress = new System.Windows.Forms.ToolStripProgressBar();
            this.lblStatusPercent = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnOutput = new System.Windows.Forms.Button();
            this.SelectFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.SaveFile = new System.Windows.Forms.SaveFileDialog();
            this.Code_Gen_Status.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAdd_Connection
            // 
            this.btnAdd_Connection.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd_Connection.Location = new System.Drawing.Point(481, 65);
            this.btnAdd_Connection.Name = "btnAdd_Connection";
            this.btnAdd_Connection.Size = new System.Drawing.Size(108, 24);
            this.btnAdd_Connection.TabIndex = 0;
            this.btnAdd_Connection.Text = "Add Connection";
            this.btnAdd_Connection.UseVisualStyleBackColor = true;
            this.btnAdd_Connection.Click += new System.EventHandler(this.btnAdd_Connection_Click);
            // 
            // txtConnectionString
            // 
            this.txtConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConnectionString.Enabled = false;
            this.txtConnectionString.Location = new System.Drawing.Point(12, 12);
            this.txtConnectionString.Name = "txtConnectionString";
            this.txtConnectionString.Size = new System.Drawing.Size(463, 23);
            this.txtConnectionString.TabIndex = 1;
            // 
            // txtData_Layer_Name
            // 
            this.txtData_Layer_Name.Location = new System.Drawing.Point(12, 65);
            this.txtData_Layer_Name.Name = "txtData_Layer_Name";
            this.txtData_Layer_Name.Size = new System.Drawing.Size(169, 23);
            this.txtData_Layer_Name.TabIndex = 2;
            this.txtData_Layer_Name.Text = "GuruDal";
            // 
            // txtBusiness_Layer_Name
            // 
            this.txtBusiness_Layer_Name.Location = new System.Drawing.Point(15, 109);
            this.txtBusiness_Layer_Name.Name = "txtBusiness_Layer_Name";
            this.txtBusiness_Layer_Name.Size = new System.Drawing.Size(169, 23);
            this.txtBusiness_Layer_Name.TabIndex = 3;
            this.txtBusiness_Layer_Name.Text = "GuruBal";
            // 
            // txtAbstract_Class_Name
            // 
            this.txtAbstract_Class_Name.Location = new System.Drawing.Point(15, 153);
            this.txtAbstract_Class_Name.Name = "txtAbstract_Class_Name";
            this.txtAbstract_Class_Name.Size = new System.Drawing.Size(169, 23);
            this.txtAbstract_Class_Name.TabIndex = 4;
            this.txtAbstract_Class_Name.Text = "GuruSqlBridge";
            // 
            // lblData_Layer_Name
            // 
            this.lblData_Layer_Name.AutoSize = true;
            this.lblData_Layer_Name.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData_Layer_Name.Location = new System.Drawing.Point(12, 47);
            this.lblData_Layer_Name.Name = "lblData_Layer_Name";
            this.lblData_Layer_Name.Size = new System.Drawing.Size(70, 15);
            this.lblData_Layer_Name.TabIndex = 5;
            this.lblData_Layer_Name.Text = "DAL-Name";
            // 
            // lblBusiness_Layer_Name
            // 
            this.lblBusiness_Layer_Name.AutoSize = true;
            this.lblBusiness_Layer_Name.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBusiness_Layer_Name.Location = new System.Drawing.Point(12, 91);
            this.lblBusiness_Layer_Name.Name = "lblBusiness_Layer_Name";
            this.lblBusiness_Layer_Name.Size = new System.Drawing.Size(69, 15);
            this.lblBusiness_Layer_Name.TabIndex = 6;
            this.lblBusiness_Layer_Name.Text = "BAL-Name";
            // 
            // lblAbstract_Class_Name
            // 
            this.lblAbstract_Class_Name.AutoSize = true;
            this.lblAbstract_Class_Name.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAbstract_Class_Name.Location = new System.Drawing.Point(12, 135);
            this.lblAbstract_Class_Name.Name = "lblAbstract_Class_Name";
            this.lblAbstract_Class_Name.Size = new System.Drawing.Size(119, 15);
            this.lblAbstract_Class_Name.TabIndex = 7;
            this.lblAbstract_Class_Name.Text = "DAL-Abstract Calss";
            // 
            // txtStatus
            // 
            this.txtStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtStatus.Location = new System.Drawing.Point(12, 183);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(577, 278);
            this.txtStatus.TabIndex = 8;
            this.txtStatus.Text = "";
            // 
            // Code_Gen_Process
            // 
            this.Code_Gen_Process.WorkerReportsProgress = true;
            this.Code_Gen_Process.WorkerSupportsCancellation = true;
            this.Code_Gen_Process.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Code_Gen_Process_DoWork);
            this.Code_Gen_Process.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.Code_Gen_Process_ProgressChanged);
            this.Code_Gen_Process.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.Code_Gen_Process_RunWorkerCompleted);
            // 
            // ckTableName
            // 
            this.ckTableName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ckTableName.Enabled = false;
            this.ckTableName.FormattingEnabled = true;
            this.ckTableName.Location = new System.Drawing.Point(244, 65);
            this.ckTableName.Name = "ckTableName";
            this.ckTableName.Size = new System.Drawing.Size(231, 112);
            this.ckTableName.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(241, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Table-Name";
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.Location = new System.Drawing.Point(481, 108);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(108, 24);
            this.btnStart.TabIndex = 11;
            this.btnStart.Text = "Genrate";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(481, 153);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(108, 24);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // Code_Gen_Status
            // 
            this.Code_Gen_Status.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.lblCode_Gen_Status,
            this.progress,
            this.lblStatusPercent});
            this.Code_Gen_Status.Location = new System.Drawing.Point(0, 464);
            this.Code_Gen_Status.Name = "Code_Gen_Status";
            this.Code_Gen_Status.Size = new System.Drawing.Size(601, 22);
            this.Code_Gen_Status.TabIndex = 13;
            this.Code_Gen_Status.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(70, 17);
            this.toolStripStatusLabel1.Text = "Code Status";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(10, 17);
            this.toolStripStatusLabel2.Text = ":";
            // 
            // lblCode_Gen_Status
            // 
            this.lblCode_Gen_Status.Name = "lblCode_Gen_Status";
            this.lblCode_Gen_Status.Size = new System.Drawing.Size(54, 17);
            this.lblCode_Gen_Status.Text = "Not Start";
            // 
            // progress
            // 
            this.progress.Name = "progress";
            this.progress.Size = new System.Drawing.Size(100, 16);
            // 
            // lblStatusPercent
            // 
            this.lblStatusPercent.Name = "lblStatusPercent";
            this.lblStatusPercent.Size = new System.Drawing.Size(46, 17);
            this.lblStatusPercent.Text = "(0.00%)";
            // 
            // btnOutput
            // 
            this.btnOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOutput.Location = new System.Drawing.Point(481, 12);
            this.btnOutput.Name = "btnOutput";
            this.btnOutput.Size = new System.Drawing.Size(108, 24);
            this.btnOutput.TabIndex = 14;
            this.btnOutput.Text = "Output Dir";
            this.btnOutput.UseVisualStyleBackColor = true;
            this.btnOutput.Click += new System.EventHandler(this.btnOutput_Click);
            // 
            // Code_Gen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 486);
            this.Controls.Add(this.btnOutput);
            this.Controls.Add(this.Code_Gen_Status);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ckTableName);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblAbstract_Class_Name);
            this.Controls.Add(this.lblBusiness_Layer_Name);
            this.Controls.Add(this.lblData_Layer_Name);
            this.Controls.Add(this.txtAbstract_Class_Name);
            this.Controls.Add(this.txtBusiness_Layer_Name);
            this.Controls.Add(this.txtData_Layer_Name);
            this.Controls.Add(this.txtConnectionString);
            this.Controls.Add(this.btnAdd_Connection);
            this.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Code_Gen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Code Gen";
            this.Code_Gen_Status.ResumeLayout(false);
            this.Code_Gen_Status.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd_Connection;
        private System.Windows.Forms.TextBox txtConnectionString;
        private System.Windows.Forms.TextBox txtData_Layer_Name;
        private System.Windows.Forms.TextBox txtBusiness_Layer_Name;
        private System.Windows.Forms.TextBox txtAbstract_Class_Name;
        private System.Windows.Forms.Label lblData_Layer_Name;
        private System.Windows.Forms.Label lblBusiness_Layer_Name;
        private System.Windows.Forms.Label lblAbstract_Class_Name;
        private System.Windows.Forms.RichTextBox txtStatus;
        private System.ComponentModel.BackgroundWorker Code_Gen_Process;
        private System.Windows.Forms.CheckedListBox ckTableName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.StatusStrip Code_Gen_Status;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel lblCode_Gen_Status;
        private System.Windows.Forms.ToolStripProgressBar progress;
        private System.Windows.Forms.ToolStripStatusLabel lblStatusPercent;
        private System.Windows.Forms.Button btnOutput;
        private System.Windows.Forms.FolderBrowserDialog SelectFolder;
        private System.Windows.Forms.SaveFileDialog SaveFile;
    }
}

