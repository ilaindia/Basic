﻿using GuruDal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DbGuru
{
    public partial class Code_Gen : Form
    {
        public Code_Gen()
        {
            InitializeComponent();
            lblCode_Gen_Status.Text = "Not Start Yet Now";
            lblStatusPercent.Text = "( 0.00% )";
            progress.Enabled = btnStart.Enabled = btnCancel.Enabled = false;
            Sql_Server.isFirst = true;
            
            SelectFolder.SelectedPath = Environment.SpecialFolder.Desktop.ToString();
            txtConnectionString.Text = SelectFolder.SelectedPath ;
        }

        private void btnAdd_Connection_Click(object sender, EventArgs e)
        {
            using (var dbConfig = new DbSource())
            {
                var result = dbConfig.ShowDialog();

                if (result == DialogResult.Cancel)
                {
                    if (Sql_Server.Table_Colection != null)
                    {

                        if (Sql_Server.Table_Colection.Rows.Count > 0)
                        {
                            ckTableName.Items.Clear();
                            foreach (DataRow dr in Sql_Server.Table_Colection.Rows)
                            {
                                ckTableName.Items.Add(dr[0].ToString(), true);
                            }
                            btnStart.Enabled = btnCancel.Enabled = ckTableName.Enabled = true;

                        }
                        else
                        {
                            btnCancel.Enabled = ckTableName.Enabled = btnStart.Enabled = false;

                        }
                    }
                    else
                    {
                        ckTableName.Enabled = btnCancel.Enabled = btnStart.Enabled = false;
                    }
                }
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (Code_Gen_Process.IsBusy != true)
            {
                // Start the asynchronous operation.
                progress.Enabled = true;
                lblCode_Gen_Status.Text = "Inprogress";
                btnOutput.Enabled = btnAdd_Connection.Enabled = false;
                _CheckedItems = ckTableName.CheckedItems;
                Code_Gen_Process.RunWorkerAsync();
            }
        }
        public static CheckedListBox.CheckedItemCollection _CheckedItems { get; set; }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (Code_Gen_Process.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                Code_Gen_Process.CancelAsync();
            }
        }

        private void Code_Gen_Process_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled == true)
            {
                lblCode_Gen_Status.Text = "Canceled!";
            }
            else if (e.Error != null)
            {
                lblCode_Gen_Status.Text = "Error: " + e.Error.Message;
            }
            else
            {
                lblCode_Gen_Status.Text = "Completed!";
            }
        }

        private void Code_Gen_Process_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progress.Value = e.ProgressPercentage;
        }

        private void Code_Gen_Process_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker Code_Gen = sender as BackgroundWorker;
            decimal Table_Count = _CheckedItems.Count;
            decimal Current_Table = 0;
            foreach (var itm in _CheckedItems)
            {
                Current_Table += 1;
                if (Code_Gen.CancellationPending == true)
                {
                    e.Cancel = true;
                }
                else
                {
                    // Perform a time consuming operation and report progress.
                    System.Threading.Thread.Sleep(500);
                    decimal progress = (Current_Table / Table_Count) * 100;
                    string Code = Load_Table_Info(itm.ToString());
                    Code_Gen.ReportProgress(Convert.ToInt32(progress));
                    SetText("( " + decimal.Round(progress, 2, MidpointRounding.AwayFromZero).ToString() + "% )", Code);
                }
            }
        }

        delegate void SetTextCallback(string text, string Code);

        private void SetText(string text, string Code)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.txtStatus.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text, Code });
            }
            else
            {
                lblStatusPercent.Text = text;
                txtStatus.Text += Code + Environment.NewLine;
            }
        }

        protected string Load_Table_Info(string Table_Name)
        {
            Master_Class bl = new Master_Class(Sql_Server.ConnectionString, "", "");
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME =@TABLE_NAME";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@TABLE_NAME", Table_Name);
                DataTable dt = bl.GetDataTable(cmd);
                dt.TableName = Table_Name;
                return Genrate(dt);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                bl.Dispose();
            }
        }

        protected string Genrate(DataTable dtCol)
        {
            Create_Coloumns(dtCol);
            string Cls_Template = "";
            using (StreamReader reader = new StreamReader(Application.StartupPath + "\\Master_Template.txt"))
            {
                Cls_Template = reader.ReadToEnd();
            }
            //Step - 1 : Replace ##Data_Layer_Name##
            Cls_Template = Cls_Template.Replace("##Data_Layer_Name##", txtData_Layer_Name.Text);
            //Step - 2 : Replace ##Business_Layer_Name##
            Cls_Template = Cls_Template.Replace("##Business_Layer_Name##", txtBusiness_Layer_Name.Text);
            //Step - 3 : Replace ##Abstract_Class_Name##
            Cls_Template = Cls_Template.Replace("##Abstract_Class_Name##", txtAbstract_Class_Name.Text);
            //Step - 4 : Replace ##Layer_Name##
            Cls_Template = Cls_Template.Replace("##Layer_Name##", GuruConvert.AsFirstLetterCaps(dtCol.TableName.ToLower()));
            //Step - 5 : Replace ##Table_Name##
            Cls_Template = Cls_Template.Replace("##Table_Name##", dtCol.TableName);
            //Step - 6 : Replace ##Create_Column_Name##
            Cls_Template = Cls_Template.Replace("##Create_Column_Name##", GuruConvert.AsString(Template.Create_Entries));
            //Step - 7 : Replace ##Insert_Update_Entries##
            Cls_Template = Cls_Template.Replace("##Insert_Update_Entries##", GuruConvert.AsString(Template.Insert_Entries));
            //Step - 8 : Replace ##Get_Entries##
            Cls_Template = Cls_Template.Replace("##Get_Entries##", GuruConvert.AsString(Template.Get_Entries));

            StreamWriter sw = null;
            try
            {
                string path = txtConnectionString.Text;
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                sw = new StreamWriter(path + "\\" + dtCol.TableName + ".cs", true);
                sw.Write(Cls_Template);
                sw.Flush();
                sw.Close();
            }
            catch
            {
            }
            return Cls_Template;
        }

        protected void Create_Coloumns(DataTable dt)
        {
            Template.Create_Entries = string.Empty;
            Template.Insert_Entries = string.Empty;
            Template.Get_Entries = string.Empty;
            foreach (DataRow dr in dt.Rows)
            {
                string Col_Name = GuruConvert.AsString(dr["COLUMN_NAME"]);
                Template.Create_Entries += Template.Create.Replace("##Col_Name##", Col_Name) + Environment.NewLine + "\t\t\t";
                if (Col_Name != "SYS_ID" && Col_Name != "ISDELETED")
                    Template.Insert_Entries += Template.Insert.Replace("##Col_Name##", Col_Name) + Environment.NewLine + "\t\t\t\t";
                Template.Get_Entries += Template.Get.Replace("##Col_Name##", Col_Name) + Environment.NewLine + "\t\t\t\t";
            }
        }

        public class Template
        {
            public static string Create_Entries { get; set; }
            public static string Create { get { return "public string ##Col_Name## { get; set; }"; } }
            public static string Insert_Entries { get; set; }
            public static string Insert { get { return "this.AddColumnParameter(\"##Col_Name##\", this.Data.##Col_Name##);"; } }
            public static string Get_Entries { get; set; }
            public static string Get { get { return "Data.##Col_Name## = GuruConvert.AsString(dt.Rows[0][\"##Col_Name##\"]);"; } }
        }

        private void btnOutput_Click(object sender, EventArgs e)
        {
            var result = SelectFolder.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                txtConnectionString.Text = SelectFolder.SelectedPath;
            }
        }

    }
}
