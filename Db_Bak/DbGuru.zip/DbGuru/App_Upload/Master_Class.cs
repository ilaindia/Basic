﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuruDal;
namespace DbGuru
{
    public class Master_Class : GuruSqlBridge
    {
        public Master_Class(string connectionString, string ActionBy, string CompanyId)
            : base(connectionString, ActionBy, CompanyId)
        {

        }
        public override System.Data.DataTable GetDataList()
        {
            throw new NotImplementedException();
        }

        public override void GetDataEntry(string keyID)
        {
            throw new NotImplementedException();
        }

        public override System.Data.DataTable GetDataEntryTable(string keyID)
        {
            throw new NotImplementedException();
        }

        public override string InsertUpdateEntry()
        {
            throw new NotImplementedException();
        }

        public override void ValidateEntry()
        {
            throw new NotImplementedException();
        }

        public override int DeleteEntry(string keyID)
        {
            throw new NotImplementedException();
        }

        public override int DeleteFlag(string keyID)
        {
            throw new NotImplementedException();
        }
    }
}
