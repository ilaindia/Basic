﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Pager
{
    public static int CurrentIndex { get; set; }
    public static int ItemCount { get; set; }
    public static int PageSize { get; set; }
}